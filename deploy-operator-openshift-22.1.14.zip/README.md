xl apply -v -f digital-ai.yaml
